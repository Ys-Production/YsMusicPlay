package com.ysmusicplay

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.delay

private val Bg = Color(0xFF101116)
private val Panel = Color(0xFF20212A)
private val Purple = Color(0xFFB79AFF)
private val Muted = Color(0xFFA7A7B2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            val controller = future.get()
            setContent { YsMusicApp(this, controller) }
        }, MoreExecutors.directExecutor())
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun YsMusicApp(context: Context, player: MediaController) {
    var tab by remember { mutableStateOf("Music") }
    var title by remember { mutableStateOf("Aucun fichier sélectionné") }
    var playing by remember { mutableStateOf(false) }
    var duration by remember { mutableLongStateOf(0L) }
    var position by remember { mutableLongStateOf(0L) }
    var sleepMinutes by remember { mutableIntStateOf(30) }
    var sleepActive by remember { mutableStateOf(false) }
    var lyrics by remember { mutableStateOf("") }
    var eqOn by remember { mutableStateOf(false) }
    var bassOn by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri ->
                runCatching {
                    context.contentResolver.takePersistableUriPermission(
                        uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
                player.addMediaItem(MediaItem.fromUri(uri))
            }
            player.prepare()
            player.play()
            title = uris.last().lastPathSegment?.substringAfterLast('/') ?: "Média sélectionné"
        }
    }

    LaunchedEffect(player) {
        while (true) {
            playing = player.isPlaying
            duration = player.duration.coerceAtLeast(0L)
            position = player.currentPosition.coerceAtLeast(0L)
            delay(500)
        }
    }

    LaunchedEffect(sleepActive, sleepMinutes) {
        if (sleepActive && sleepMinutes > 0) {
            delay(sleepMinutes * 60_000L)
            player.pause()
            playing = false
            sleepActive = false
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Purple,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF171820)) {
                    listOf("Music", "Video", "Tools").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {
                                Icon(when (item) {
                                    "Music" -> Icons.Default.MusicNote
                                    "Video" -> Icons.Default.Videocam
                                    else -> Icons.Default.Tune
                                }, contentDescription = item)
                            },
                            label = { Text(item) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Purple, selectedTextColor = Purple
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                Row(
                    Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 22.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(shape = RoundedCornerShape(14.dp), color = Panel, modifier = Modifier.size(46.dp)) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.GraphicEq, null, tint = Purple)
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("YS MUSIC PLAY", fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                        Text("Your music. Your world.", color = Muted, fontSize = 11.sp)
                    }
                    IconButton(onClick = { picker.launch(arrayOf("audio/*", "video/*")) }) {
                        Icon(Icons.Default.Add, "Ajouter", tint = Purple)
                    }
                }

                when (tab) {
                    "Music" -> {
                        Text("NOW PLAYING", color = Purple, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        Surface(color = Panel, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(18.dp)) {
                                Box(
                                    Modifier.fillMaxWidth().height(165.dp).background(
                                        androidx.compose.ui.graphics.Brush.linearGradient(
                                            listOf(Color(0xFF39265D), Color(0xFF151722)
                                        )), RoundedCornerShape(18.dp)
                                    ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.GraphicEq, null, tint = Purple, modifier = Modifier.size(76.dp))
                                }
                                Spacer(Modifier.height(18.dp))
                                Text(title, fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text("Lecture locale", color = Muted, fontSize = 12.sp)
                                Spacer(Modifier.height(12.dp))
                                Slider(
                                    value = if (duration > 0) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f,
                                    onValueChange = { if (duration > 0) player.seekTo(it.toLong()) },
                                    valueRange = 0f..duration.coerceAtLeast(1L).toFloat(),
                                    colors = SliderDefaults.colors(thumbColor = Purple, activeTrackColor = Purple)
                                )
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(formatTime(position), color = Muted, fontSize = 11.sp)
                                    Text(formatTime(duration), color = Muted, fontSize = 11.sp)
                                }
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceEvenly,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(onClick = { player.shuffleModeEnabled = !player.shuffleModeEnabled }) {
                                        Icon(Icons.Default.Shuffle, null, tint = Purple)
                                    }
                                    IconButton(onClick = { player.seekToPrevious() }) {
                                        Icon(Icons.Default.SkipPrevious, null)
                                    }
                                    FilledIconButton(
                                        onClick = { if (player.isPlaying) player.pause() else player.play() },
                                        colors = IconButtonDefaults.filledIconButtonColors(
                                            containerColor = Purple, contentColor = Bg
                                        ),
                                        modifier = Modifier.size(58.dp)
                                    ) {
                                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null)
                                    }
                                    IconButton(onClick = { player.seekToNext() }) {
                                        Icon(Icons.Default.SkipNext, null)
                                    }
                                    IconButton(onClick = {
                                        player.repeatMode = if (player.repeatMode == Player.REPEAT_MODE_OFF)
                                            Player.REPEAT_MODE_ALL else Player.REPEAT_MODE_OFF
                                    }) { Icon(Icons.Default.Repeat, null, tint = Purple) }
                                }
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                        Text("YOUR LIBRARY", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            AssistChip(onClick = { picker.launch(arrayOf("audio/*")) },
                                label = { Text("Choisir MP3") },
                                leadingIcon = { Icon(Icons.Default.MusicNote, null) })
                            AssistChip(onClick = { picker.launch(arrayOf("video/*")) },
                                label = { Text("Choisir MP4") },
                                leadingIcon = { Icon(Icons.Default.VideoLibrary, null) })
                        }
                        Text("Ajoute tes fichiers depuis le stockage du téléphone.", color = Muted, fontSize = 11.sp)
                    }
                    "Video" -> {
                        Text("VIDEO PLAYER", color = Purple, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.VideoLibrary, null, tint = Purple, modifier = Modifier.size(64.dp))
                                Text("Lecteur vidéo MP4", fontWeight = FontWeight.Bold)
                                Text("Sélectionne une vidéo avec le bouton ci-dessous.", color = Muted, fontSize = 12.sp)
                                Button(onClick = { picker.launch(arrayOf("video/*")) }) { Text("Choisir une vidéo") }
                                Text("La lecture est gérée par Media3 ; l'écran vidéo intégré sera amélioré dans une prochaine version.",
                                    color = Muted, fontSize = 11.sp)
                            }
                        }
                    }
                    else -> {
                        Text("AUDIO TOOLS", color = Purple, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("Equalizer", Modifier.weight(1f))
                            Switch(eqOn, onCheckedChange = { eqOn = it })
                        }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("Bass Booster", Modifier.weight(1f))
                            Switch(bassOn, onCheckedChange = { bassOn = it })
                        }
                        Text("Les interrupteurs sont des commandes d'interface dans ce socle V1 ; le branchement aux effets audio natifs dépendra du périphérique et sera finalisé après test.",
                            color = Muted, fontSize = 11.sp)
                        Spacer(Modifier.height(18.dp))
                        Text("SLEEP TIMER", fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(15, 30, 45, 60).forEach { mins ->
                                FilterChip(
                                    selected = sleepMinutes == mins,
                                    onClick = { sleepMinutes = mins; sleepActive = false },
                                    label = { Text("${mins}m") }
                                )
                            }
                        }
                        Button(onClick = { sleepActive = sleepMinutes > 0 }) { Text("Activer le timer") }
                        OutlinedButton(onClick = { sleepActive = false }) { Text("Annuler le timer") }
                        if (sleepActive) Text("Arrêt programmé dans $sleepMinutes minutes.", color = Purple)
                        Spacer(Modifier.height(18.dp))
                        Text("LYRICS", fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = lyrics, onValueChange = { lyrics = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Saisis les paroles ici…") },
                            minLines = 3
                        )
                        Text("Paroles manuelles dans cette V1 ; pas de synchronisation automatique.",
                            color = Muted, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    if (ms < 0) return "00:00"
    val seconds = ms / 1000
    return "%02d:%02d".format(seconds / 60, seconds % 60)
}
