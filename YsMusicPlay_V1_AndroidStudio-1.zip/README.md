# Ys Music Play V1

Projet Android natif en Kotlin, Jetpack Compose et AndroidX Media3.

## Inclus
- Interface Premium Dark.
- Sélection locale de fichiers audio et vidéo via le sélecteur Android.
- File de lecture Media3, lecture/pause, précédent/suivant, progression, shuffle et repeat.
- Service MediaSession pour préparer la lecture audio en arrière-plan et les commandes multimédias système.
- Sleep timer avec choix 15, 30, 45 ou 60 minutes.
- Zone de paroles saisies manuellement.
- Écrans Music, Video et Tools.

## Ouvrir le projet
1. Installer Android Studio récent et JDK 17.
2. Ouvrir le dossier du projet dans Android Studio.
3. Laisser Gradle télécharger les dépendances.
4. Lancer sur un appareil Android ou un émulateur.

Pour produire un APK : Build > Build Bundle(s) / APK(s) > Build APK(s).

## Limites de ce premier socle
- La bibliothèque n'est pas encore indexée automatiquement : les médias sont ajoutés via le sélecteur.
- L'écran vidéo intégré et les contrôles plein écran sont à terminer.
- Equalizer et Bass Booster sont actuellement des commandes d'interface, pas encore reliées aux effets natifs.
- Les paroles sont manuelles et non synchronisées.
- Le projet doit être compilé et testé dans Android Studio sur l'appareil cible avant diffusion.

## Versions
Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Media3 1.5.1, Compose BOM 2024.12.01.
