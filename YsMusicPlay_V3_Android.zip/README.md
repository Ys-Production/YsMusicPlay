# Ys Music Play V3

Kinova fanavaozana mifototra amin'ny projet V2 teo aloha. Endrika maizina misy loko volomboasary, araka ny interface VLC nalefan'ny mpampiasa.

## Ao anatin'ity kinova ity
- Pejy Audio sy Video misaraka.
- Fikarohana hira sy vidéo.
- Famakiana MediaStore ho an'ny audio sy vidéo, miaraka amin'ny fahazoan-dalana Android.
- Sokajy Hira / Rakikira / Mpanakanto.
- Fanasokajiana hira araka ny anarana, daty nampidirana, na faharetana.
- Pejy Now Playing misaraka ho an'ny hira.
- Pejy Video Player misaraka.
- Queue: lisitry ny media ao amin'ny filaharana, azo fidina ny hira manaraka.
- Shuffle sy Repeat All.
- Mini-player eo ambonin'ny navigation.
- MediaSessionService ho an'ny fanaraha-maso amin'ny notification sy lock screen.
- Equalizer sy BassBoost native raha tohanan'ny fitaovana.
- About miafina ao ambadiky ny kisary Info.

## Zava-dehibe
- Ny paroles dia azo ampidirina amin'ny alalan'ny efijery Tononkira; tsy mbola misy motera mitady paroles amin'ny Internet na fampifanarahana LRC.
- Ny sary fonon-kira dia ampidirina ao amin'ny metadata Media3, saingy ny fampisehoana azy amin'ny efijery lehibe dia mbola mila fanamarinana amin'ny fitaovana.
- Ny fanaraha-maso lock screen/notification dia miankina amin'ny MediaSession sy ny politikan'ny Android amin'ny fitaovana.
- Ny Equalizer/BassBoost dia miankina amin'ny fanohanan'ny finday sy ny audio session.
- Ny scan MediaStore dia mampiasa ny fahazoan-dalana READ_MEDIA_AUDIO/VIDEO amin'ny Android 13+ ary READ_EXTERNAL_STORAGE amin'ny Android 12 sy ambany.
- Tsy mbola voasedra tamin'ny Android Studio na fitaovana tena izy ity archive ity. Ny GitHub Actions build sy ny fitsapana amin'ny finday no hanamarina raha misy olana.

## Fanamboarana APK amin'ny GitHub
Ny workflow `.github/workflows/build.yml` dia manamboatra `app-debug.apk` ary mamorona artifact `YsMusicPlay-V2.1-APK`.


## Torolalana
Jereo ny rakitra GUIDE_COMPLET_YsMusicPlay_V3.txt ao amin'ity archive ity.
