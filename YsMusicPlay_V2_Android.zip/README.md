# Ys Music Play V2

Projet Android Kotlin + Jetpack Compose + Media3.

## Construction depuis un téléphone Android
Le dépôt GitHub peut compiler ce projet avec GitHub Actions. Importer le contenu de cette archive dans le dépôt `Ys-Production/YsMusicPlay`, puis lancer le workflow de build.

## Fonctionnalités présentes dans cette base V2
- Scan MediaStore de la bibliothèque audio et vidéo après autorisation Android.
- Listes Songs / Albums / Artists.
- Durée et progression lues depuis le lecteur Media3.
- Lecture suivante/précédente, lecture automatique, shuffle Media3 et repeat all.
- Lecteur vidéo Media3 intégré.
- Tri par nom et durée (le choix Date est affiché comme option d'interface mais le tri date n'est pas encore implémenté).
- Effets Android Equalizer et BassBoost, si le périphérique les prend en charge.
- Sleep timer et page À propos.

## Limites connues à tester sur appareil
- Les paroles ne sont pas récupérées automatiquement sur Internet. La saisie manuelle est disponible ; l'intégration complète des fichiers LRC synchronisés est à finaliser.
- La pochette intégrée n'est pas encore affichée dans l'interface.
- Le tri Date est à finaliser.
- Le comportement des effets EQ/Bass varie selon le téléphone et la session audio.
- Ce projet doit être compilé puis testé sur le téléphone. Un build vert ne garantit pas à lui seul le bon fonctionnement de toutes les fonctions.
