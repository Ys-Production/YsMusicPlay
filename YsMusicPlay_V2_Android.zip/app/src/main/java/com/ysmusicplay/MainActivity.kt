package com.ysmusicplay

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import java.util.Locale

private val Bg = Color(0xFF101116)
private val Panel = Color(0xFF20212A)
private val Purple = Color(0xFFB79AFF)
private val Muted = Color(0xFFA7A7B2)

data class Track(
    val id: Long, val title: String, val artist: String, val album: String,
    val duration: Long, val uri: Uri, val isVideo: Boolean = false,
    val folder: String = ""
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { YsMusicApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun YsMusicApp() {
    val context = LocalContext.current
    val player = remember { ExoPlayer.Builder(context).build() }
    var tab by remember { mutableStateOf("Music") }
    var libraryTab by remember { mutableStateOf("Songs") }
    var tracks by remember { mutableStateOf(listOf<Track>()) }
    var videos by remember { mutableStateOf(listOf<Track>()) }
    var currentTitle by remember { mutableStateOf("Aucun fichier sélectionné") }
    var currentArtist by remember { mutableStateOf("") }
    var playing by remember { mutableStateOf(false) }
    var duration by remember { mutableLongStateOf(0L) }
    var position by remember { mutableLongStateOf(0L) }
    var sortMode by remember { mutableStateOf("Name") }
    var shuffle by remember { mutableStateOf(false) }
    var repeat by remember { mutableStateOf(false) }
    var lyrics by remember { mutableStateOf("Ajoute un fichier .lrc portant le même nom que la chanson pour afficher les paroles synchronisées. Tu peux aussi saisir les paroles ici.") }
    var lyricsEdit by remember { mutableStateOf("") }
    var showLyrics by remember { mutableStateOf(false) }
    var eqEnabled by remember { mutableStateOf(false) }
    var bassEnabled by remember { mutableStateOf(false) }
    var sleepMinutes by remember { mutableIntStateOf(30) }
    var sleepActive by remember { mutableStateOf(false) }
    var scanMessage by remember { mutableStateOf("Autorise l'accès aux fichiers pour analyser ta bibliothèque.") }
    var eq by remember { mutableStateOf<Equalizer?>(null) }
    var bass by remember { mutableStateOf<BassBoost?>(null) }

    fun scanLibrary() {
        val audioList = mutableListOf<Track>()
        val videoList = mutableListOf<Track>()
        val audioCollection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val audioProjection = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.DATA
        )
        runCatching {
            context.contentResolver.query(audioCollection, audioProjection,
                "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
                "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val dataCol = c.getColumnIndex(MediaStore.Audio.Media.DATA)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val path = if (dataCol >= 0) c.getString(dataCol).orEmpty() else ""
                    audioList.add(Track(id, c.getString(titleCol) ?: "Unknown",
                        c.getString(artistCol) ?: "Unknown artist",
                        c.getString(albumCol) ?: "Unknown album",
                        c.getLong(durationCol),
                        ContentUris.withAppendedId(audioCollection, id),
                        folder = path.substringBeforeLast("/", "Music")))
                }
            }
        }
        val videoCollection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val videoProjection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DURATION, MediaStore.Video.Media.DATA)
        runCatching {
            context.contentResolver.query(videoCollection, videoProjection, null, null,
                "${MediaStore.Video.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val durationCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val dataCol = c.getColumnIndex(MediaStore.Video.Media.DATA)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val path = if (dataCol >= 0) c.getString(dataCol).orEmpty() else ""
                    videoList.add(Track(id, c.getString(titleCol) ?: "Video",
                        "", "", c.getLong(durationCol),
                        ContentUris.withAppendedId(videoCollection, id), true,
                        path.substringBeforeLast("/", "Videos")))
                }
            }
        }
        tracks = audioList
        videos = videoList
        scanMessage = "${audioList.size} chansons et ${videoList.size} vidéos trouvées."
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) scanLibrary() else scanMessage = "Permission refusée. Autorise l'accès aux fichiers dans les paramètres Android."
    }
    LaunchedEffect(Unit) {
        val permission = Manifest.permission.READ_EXTERNAL_STORAGE
        if (Build.VERSION.SDK_INT <= 32 &&
            ContextCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(permission)
        } else scanLibrary()
    }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val idx = player.currentMediaItemIndex
                if (idx in tracks.indices) {
                    currentTitle = tracks[idx].title
                    currentArtist = tracks[idx].artist
                }
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
            eq?.release()
            bass?.release()
        }
    }
    LaunchedEffect(player) {
        while (true) {
            playing = player.isPlaying
            duration = player.duration.takeIf { it > 0 } ?: 0L
            position = player.currentPosition.coerceAtLeast(0L)
            delay(400)
        }
    }
    LaunchedEffect(sleepActive, sleepMinutes) {
        if (sleepActive) {
            delay(sleepMinutes * 60_000L)
            player.pause()
            sleepActive = false
        }
    }

    fun playTrack(track: Track, list: List<Track>) {
        val items = list.map { MediaItem.fromUri(it.uri) }
        player.setMediaItems(items, list.indexOf(track).coerceAtLeast(0), 0L)
        player.shuffleModeEnabled = shuffle
        player.repeatMode = if (repeat) Player.REPEAT_MODE_ALL else Player.REPEAT_MODE_OFF
        player.prepare()
        player.play()
        currentTitle = track.title
        currentArtist = track.artist
        tab = if (track.isVideo) "Video" else "Music"
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Purple,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Color(0xFF171820)) {
                listOf("Music", "Video", "Tools").forEach { item ->
                    NavigationBarItem(selected = tab == item, onClick = { tab = item },
                        icon = { Icon(when(item) {
                            "Music" -> Icons.Default.MusicNote
                            "Video" -> Icons.Default.Videocam
                            else -> Icons.Default.Tune
                        }, null) }, label = { Text(item) })
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.GraphicEq, null, tint = Purple, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("YS MUSIC PLAY", fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                        Text("Ys Production", color = Muted, fontSize = 11.sp)
                    }
                    IconButton(onClick = { scanLibrary() }) { Icon(Icons.Default.Refresh, "Scanner", tint = Purple) }
                }
                when (tab) {
                    "Music" -> {
                        Text("LECTEUR AUDIO", color = Purple, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                            Column(Modifier.padding(14.dp)) {
                                Text(currentTitle, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text(currentArtist, color = Muted, fontSize = 12.sp)
                                Slider(value = if (duration > 0) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f,
                                    onValueChange = { if (duration > 0) player.seekTo(it.toLong()) },
                                    valueRange = 0f..duration.coerceAtLeast(1L).toFloat())
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(time(position), color = Muted, fontSize = 11.sp)
                                    Text(time(duration), color = Muted, fontSize = 11.sp)
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly,
                                    verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { shuffle = !shuffle; player.shuffleModeEnabled = shuffle }) {
                                        Icon(Icons.Default.Shuffle, null, tint = if(shuffle) Purple else Muted)
                                    }
                                    IconButton(onClick = { player.seekToPrevious() }) { Icon(Icons.Default.SkipPrevious, null) }
                                    FilledIconButton(onClick = { if(player.isPlaying) player.pause() else player.play() }) {
                                        Icon(if(playing) Icons.Default.Pause else Icons.Default.PlayArrow, null)
                                    }
                                    IconButton(onClick = { player.seekToNext() }) { Icon(Icons.Default.SkipNext, null) }
                                    IconButton(onClick = {
                                        repeat = !repeat
                                        player.repeatMode = if(repeat) Player.REPEAT_MODE_ALL else Player.REPEAT_MODE_OFF
                                    }) { Icon(Icons.Default.Repeat, null, tint = if(repeat) Purple else Muted) }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { showLyrics = !showLyrics }) { Text("Paroles") }
                                    OutlinedButton(onClick = { tab = "Tools" }) { Text("Égaliseur") }
                                }
                            }
                        }
                        if (showLyrics) {
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(value = lyricsEdit, onValueChange = { lyricsEdit = it },
                                label = { Text("Paroles / texte .LRC") }, modifier = Modifier.fillMaxWidth())
                            Text(lyrics, color = Muted, fontSize = 11.sp)
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically) {
                            Text("BIBLIOTHÈQUE", fontWeight = FontWeight.Bold)
                            Text("${tracks.size} titres", color = Muted, fontSize = 12.sp)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Songs", "Albums", "Artists").forEach { value ->
                                FilterChip(selected = libraryTab == value, onClick = { libraryTab = value }, label = { Text(value) })
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Tri :", color = Muted)
                            Spacer(Modifier.width(8.dp))
                            listOf("Name", "Date", "Duration").forEach { value ->
                                TextButton(onClick = { sortMode = value }) {
                                    Text(value, color = if(sortMode == value) Purple else Muted)
                                }
                            }
                        }
                        val visibleTracks = when(libraryTab) {
                            "Albums" -> tracks.distinctBy { it.album }
                            "Artists" -> tracks.distinctBy { it.artist }
                            else -> when(sortMode) {
                                "Duration" -> tracks.sortedByDescending { it.duration }
                                else -> tracks.sortedBy { it.title.lowercase(Locale.ROOT) }
                            }
                        }
                        LazyColumn(Modifier.weight(1f)) {
                            items(visibleTracks) { track ->
                                ListItem(
                                    headlineContent = { Text(if(libraryTab == "Albums") track.album else if(libraryTab == "Artists") track.artist else track.title, maxLines = 1) },
                                    supportingContent = { Text(if(libraryTab == "Songs") "${track.artist} • ${time(track.duration)}" else "${track.artist} • ${track.album}", color = Muted) },
                                    leadingContent = { Icon(Icons.Default.MusicNote, null, tint = Purple) },
                                    modifier = Modifier.clickable { playTrack(track, tracks) },
                                    colors = ListItemDefaults.colors(containerColor = Bg)
                                )
                            }
                        }
                        Text(scanMessage, color = Muted, fontSize = 10.sp)
                    }
                    "Video" -> {
                        Text("BIBLIOTHÈQUE VIDÉO", color = Purple, fontWeight = FontWeight.Bold)
                        if (player.currentMediaItem != null && currentTitle.isNotBlank()) {
                            AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true } },
                                modifier = Modifier.fillMaxWidth().height(220.dp))
                        }
                        Text("${videos.size} vidéos trouvées", color = Muted, fontSize = 12.sp)
                        LazyColumn {
                            items(videos) { video ->
                                ListItem(headlineContent = { Text(video.title) },
                                    supportingContent = { Text("${video.folder} • ${time(video.duration)}", color = Muted) },
                                    leadingContent = { Icon(Icons.Default.VideoFile, null, tint = Purple) },
                                    modifier = Modifier.clickable { playTrack(video, videos) },
                                    colors = ListItemDefaults.colors(containerColor = Bg))
                            }
                        }
                    }
                    else -> {
                        Text("OUTILS AUDIO", color = Purple, fontWeight = FontWeight.Bold)
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("Equalizer natif", Modifier.weight(1f))
                            Switch(eqEnabled, onCheckedChange = {
                                eqEnabled = it
                                runCatching {
                                    if (eq == null && player.audioSessionId > 0) eq = Equalizer(0, player.audioSessionId)
                                    eq?.enabled = it
                                }
                            })
                        }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("Bass Booster", Modifier.weight(1f))
                            Switch(bassEnabled, onCheckedChange = {
                                bassEnabled = it
                                runCatching {
                                    if (bass == null && player.audioSessionId > 0) bass = BassBoost(0, player.audioSessionId)
                                    bass?.setStrength(if(it) 800.toShort() else 0.toShort())
                                    bass?.enabled = it
                                }
                            })
                        }
                        Text("Les effets audio dépendent de la compatibilité du téléphone et de la session audio.", color = Muted, fontSize = 11.sp)
                        Spacer(Modifier.height(20.dp))
                        Text("SLEEP TIMER", fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(15, 30, 45, 60).forEach { m ->
                                FilterChip(selected = sleepMinutes == m, onClick = { sleepMinutes = m; sleepActive = false }, label = { Text("${m} min") })
                            }
                        }
                        Button(onClick = { sleepActive = true }) { Text("Activer le timer") }
                        OutlinedButton(onClick = { sleepActive = false }) { Text("Annuler") }
                        if(sleepActive) Text("Arrêt programmé dans $sleepMinutes minutes", color = Purple)
                        Spacer(Modifier.height(24.dp))
                        Text("À PROPOS", fontWeight = FontWeight.Bold)
                        Text("Ys Music Play V2", color = Purple)
                        Text("Créateur : Haritiana")
                        Text("Studio : Ys Production")
                        Text("WhatsApp : +261 33 95 146 95")
                    }
                }
            }
        }
    }
}

private fun time(ms: Long): String {
    if (ms <= 0) return "0:00"
    val seconds = ms / 1000
    return "%d:%02d".format(seconds / 60, seconds % 60)
}
